# StudentHub Backend

Node.js + Express + MySQL API for the StudentHub frontend.

## Requirements
- Node.js LTS
- MySQL Server

## 1. Create the database
Run `schema.sql` in MySQL Workbench or the MySQL command line.

## 2. Configure credentials
Copy `.env.example` to `.env`, then set your MySQL username and password.
Never share or commit `.env`.

## 3. Install packages
Run `npm install` in this backend folder.

## 4. Start the API
Run `npm run dev` (or `npm start`).

Expected output:
- Connected to MySQL database.
- StudentHub API running at http://localhost:5000

## API endpoints
- GET `/api/students` — list students
- GET `/api/students/:id` — retrieve one student
- POST `/api/students` — add student
- PUT `/api/students/:id` — update student
- DELETE `/api/students/:id` — delete student

POST/PUT JSON example:
```json
{
  "student_id": "STU005",
  "name": "John Peter",
  "email": "john@gmail.com",
  "class_name": "Year 1 - Software",
  "status": "Active"
}
```

The frontend is not connected automatically yet. We will update `frontend/script.js` after confirming the API and database work.
